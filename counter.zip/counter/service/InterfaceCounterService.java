package com.trilink.counter.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 统计接口请求量
 * @author acer
 *
 */
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.trilink.counter.entity.InterfaceCounter;
import com.trilink.counter.entity.InterfaceCounterExample;
import com.trilink.counter.mapper.InterfaceCounterMapper;
@Service
public class InterfaceCounterService {
	@Autowired
	private InterfaceCounterMapper interfaceCounterMapper;

	/**
	 * 统计接口请求信息
	 * @param type 类型，1:年,2:月,3:日,4:小时,5:分
	 * @param year
	 * @param month
	 * @param day
	 * @param hour
	 * @param min
	 * @return
	 */
	public Map<String, Object> counterInterface(Integer type,Integer year,Integer month,Integer day,Integer hour) {
		Map<String,Object>result=new HashMap<String,Object>();
		Calendar calendar=Calendar.getInstance();
		List<Date> timeList=null;
		if(type==1) {//年
			timeList=getListYear(calendar.get(Calendar.YEAR),year);
		}else if(type==2) {//月
			timeList=getListMonth(year);
		}else if(type==3) {//日
			timeList=getListDay(year, month);
		}else if(type==4) {//时
			timeList=getListHour(year, month, day);
		}else if(type==5) {//分
			timeList=getListMinut(year, month, day, hour);
		}
		if(timeList==null||timeList.size()<1) {
			result.put("errCode", 101);
			result.put("errMsg", "输入的参数存在问题");
			return result;
		}else {
			Date start=null;
			Date end=null;
			//总请求量
			List<Integer>numberList=new ArrayList<Integer>();
			//描述
			List<Integer> decsList=new ArrayList<Integer>();
			//成功请求量
			List<Integer>successList=new ArrayList<Integer>();
			for(int i=0;i<timeList.size()-1;i++) {
				start=timeList.get(i);
				end=timeList.get(i+1);
				InterfaceCounterExample interfaceCounterExample =new InterfaceCounterExample();
				InterfaceCounterExample.Criteria interfaceCounterExampleCriteria = interfaceCounterExample.createCriteria();
				interfaceCounterExampleCriteria.andCreateTimeBetween(start, end);
				int count=interfaceCounterMapper.countByExample(interfaceCounterExample);
				numberList.add(count);
				
				InterfaceCounterExample interfaceCounterExample2 =new InterfaceCounterExample();
				InterfaceCounterExample.Criteria interfaceCounterExampleCriteria2 = interfaceCounterExample2.createCriteria();
				interfaceCounterExampleCriteria2.andStatusEqualTo(0);
				interfaceCounterExampleCriteria2.andCreateTimeBetween(start, end);
				int countSuccess=interfaceCounterMapper.countByExample(interfaceCounterExample2);
				successList.add(countSuccess);
				
				//根据不同的类型返回不同的坐标数据
				if(type==1) {//年
					decsList.add(start.getYear()+1900);
				}else if(type==2) {//月
					decsList.add(start.getMonth()+1);
				}else if(type==3) {//日
					decsList.add(start.getDate());
				}else if(type==4) {//时
					decsList.add(start.getHours());
				}else if(type==5) {//分
					decsList.add(start.getMinutes());
				}
			}
			
			result.put("dataY", numberList);
			result.put("sdataY", successList);
			result.put("dataX", decsList);
			result.put("errCode", 0);
			result.put("errMsg", "查询成功");
		}
		return result;
	}
	
	/**
	 * 根据日期统计每个接口调用情况
	 * @param type
	 * @param year
	 * @param month
	 * @param day
	 * @param hour
	 * @return
	 */
	public Map<String, Object> counterMathods(Integer type, Integer year, Integer month, Integer day, Integer hour) {
		Map<String,Object>result=new HashMap<String,Object>();
		Date start=getFirstDate(type,year, month, day, hour);
		Date end=getLastDate(type,year, month, day, hour);
		List<InterfaceCounter> list=interfaceCounterMapper.countByDate(start, end);
		List<String>dataY=new ArrayList<String>();
		List<Integer>dataX=new ArrayList<Integer>();
		for(InterfaceCounter item:list) {
			dataY.add(item.getPath());
			dataX.add(item.getNum());
		}
		result.put("dataY", dataY);
		result.put("dataX", dataX);
		result.put("errCode", 0);
		result.put("errMsg", "查询成功");
		return result;
	}
	
	public Map<String, Object> mathodsDetail(Integer order,Integer page, Integer rows,String start,String end) throws Exception {
		Map<String,Object>result=new HashMap<String,Object>();
		InterfaceCounterExample interfaceCounterExample = new InterfaceCounterExample();
		InterfaceCounterExample.Criteria InterfaceCounterExampleCriteria=interfaceCounterExample.createCriteria();
		if(order==1) {
			interfaceCounterExample.setOrderByClause("create_time desc");
		}else {
			interfaceCounterExample.setOrderByClause("create_time asc");
		}
		//当时间不为空时根据时间段查询
		if(start!=null&&!start.equals("")&&end!=null&&!end.equals("")) {
			SimpleDateFormat fmt=new SimpleDateFormat("yyyy-MM-dd HH:mm");
			Date startDate=fmt.parse(start);
			Date endDate=fmt.parse(end);
			InterfaceCounterExampleCriteria.andCreateTimeBetween(startDate, endDate);
		}
		PageHelper.startPage(page, rows);
		List<InterfaceCounter> list=interfaceCounterMapper.selectByExample(interfaceCounterExample);
		PageInfo<InterfaceCounter> pages=new PageInfo<>(list);
		result.put("data", list);
		result.put("tatal", pages.getTotal());
		result.put("errCode", 0);
		result.put("errMsg", "查询成功");
		return result;
	}
	/**
	 * 获取当前时间的第一时刻
	 * @param type 1:年，2：月，3：日，4:小时
	 * @param year
	 * @param month
	 * @param day
	 * @param hour
	 * @return
	 */
	private static Date getFirstDate(Integer type, Integer year, Integer month, Integer day, Integer hour) {
		Calendar calendar=Calendar.getInstance();
		if(type==1) {
			calendar.set(Calendar.YEAR, year);
			calendar.set(Calendar.MONTH, 0);
			calendar.set(Calendar.DAY_OF_MONTH, 1);
			calendar.set(Calendar.HOUR_OF_DAY, 0);
			calendar.set(Calendar.MINUTE, 0);
			calendar.set(Calendar.SECOND, 0);
			return calendar.getTime();
		}else if(type==2) {
			calendar.set(Calendar.YEAR, year);
			calendar.set(Calendar.MONTH, month-1);
			calendar.set(Calendar.DAY_OF_MONTH, 1);
			calendar.set(Calendar.HOUR_OF_DAY, 0);
			calendar.set(Calendar.MINUTE, 0);
			calendar.set(Calendar.SECOND, 0);
			return calendar.getTime();
		}else if(type==3) {
			calendar.set(Calendar.YEAR, year);
			calendar.set(Calendar.MONTH, month-1);
			calendar.set(Calendar.DAY_OF_MONTH,day);
			calendar.set(Calendar.HOUR_OF_DAY, 0);
			calendar.set(Calendar.MINUTE, 0);
			calendar.set(Calendar.SECOND, 0);
			return calendar.getTime();
		}else if(type==4||type==5) {
			calendar.set(Calendar.YEAR, year);
			calendar.set(Calendar.MONTH, month-1);
			calendar.set(Calendar.DAY_OF_MONTH,day);
			calendar.set(Calendar.HOUR_OF_DAY, hour);
			calendar.set(Calendar.MINUTE, 0);
			calendar.set(Calendar.SECOND, 0);
			return calendar.getTime();
		}
		return null;
	}
	
	/**
	 * 获取当前时间的第一时刻
	 * @param type 1:年，2：月，3：日，4:小时
	 * @param year
	 * @param month
	 * @param day
	 * @param hour
	 * @return
	 */
	private static Date getLastDate(Integer type, Integer year, Integer month, Integer day, Integer hour) {
		Calendar calendar=Calendar.getInstance();
		if(type==1) {
			calendar.set(Calendar.YEAR, year+1);
			calendar.set(Calendar.MONTH, 0);
			calendar.set(Calendar.DAY_OF_MONTH, 1);
			calendar.set(Calendar.HOUR_OF_DAY, 0);
			calendar.set(Calendar.MINUTE, 0);
			calendar.set(Calendar.SECOND, -1);
			return calendar.getTime();
		}else if(type==2) {
			calendar.set(Calendar.YEAR, year);
			calendar.set(Calendar.MONTH, month);
			calendar.set(Calendar.DAY_OF_MONTH, 1);
			calendar.set(Calendar.HOUR_OF_DAY, 0);
			calendar.set(Calendar.MINUTE, 0);
			calendar.set(Calendar.SECOND, -1);
			return calendar.getTime();
		}else if(type==3) {
			calendar.set(Calendar.YEAR, year);
			calendar.set(Calendar.MONTH, month-1);
			calendar.set(Calendar.DAY_OF_MONTH,day+1);
			calendar.set(Calendar.HOUR_OF_DAY, 0);
			calendar.set(Calendar.MINUTE, 0);
			calendar.set(Calendar.SECOND, -1);
			return calendar.getTime();
		}else if(type==4||type==5) {
			calendar.set(Calendar.YEAR, year);
			calendar.set(Calendar.MONTH, month-1);
			calendar.set(Calendar.DAY_OF_MONTH,day);
			calendar.set(Calendar.HOUR_OF_DAY, hour+1);
			calendar.set(Calendar.MINUTE, 0);
			calendar.set(Calendar.SECOND, -1);
			return calendar.getTime();
		}
		return null;
	}
	
	/**
	 * 获取年的列表
	 * @param year
	 * @return
	 */
	private static List<Date> getListYear(int current,int year) {
		List<Date>list=new ArrayList<Date>();
		Calendar calendar=Calendar.getInstance();
		Date cur=calendar.getTime();
		for(;current>=year;year++) {
			calendar.set(Calendar.YEAR, year);
			calendar.set(Calendar.MONTH, 0);
			calendar.set(Calendar.DAY_OF_MONTH, 1);
			calendar.set(Calendar.HOUR_OF_DAY, 0);
			calendar.set(Calendar.MINUTE, 0);
			calendar.set(Calendar.SECOND, 0);
			list.add(calendar.getTime());
		}
		list.add(cur);
		return list;
	}
	/**
	 * 获取月列表
	 * @param currentYear
	 * @param year
	 * @param month
	 * @return
	 */
	private static List<Date>getListMonth(int year){
		List<Date>list=new ArrayList<Date>();
		Calendar calendar=Calendar.getInstance();
		Date current=calendar.getTime();
		int currentYear=calendar.get(Calendar.YEAR);
		int end=0;
		if(year<calendar.get(Calendar.YEAR)) {
			end=11;
		}else {
			end=calendar.get(Calendar.MONTH);
		}
		for(int i=0;i<=end;i++) {
			calendar.set(Calendar.YEAR, year);
			calendar.set(Calendar.MONTH, i);
			calendar.set(Calendar.DAY_OF_MONTH, 1);
			calendar.set(Calendar.HOUR_OF_DAY, 0);
			calendar.set(Calendar.MINUTE, 0);
			calendar.set(Calendar.SECOND, 0);
			list.add(calendar.getTime());
		}
		if(year>=currentYear) {
			list.add(current);
		}else {
			calendar.set(Calendar.YEAR, year+1);
			calendar.set(Calendar.MONTH, 0);
			calendar.set(Calendar.DAY_OF_MONTH, 1);
			calendar.set(Calendar.HOUR_OF_DAY, 0);
			calendar.set(Calendar.MINUTE, 0);
			calendar.set(Calendar.SECOND, -1);
			list.add(calendar.getTime());
		}
		return list;
	}
	/**
	 * 获取某个月对应的日
	 * @param year
	 * @param month
	 * @return
	 */
	private static List<Date>getListDay(int year,int month){
		List<Date>list=new ArrayList<Date>();
		Calendar calendar=Calendar.getInstance();
		Date current=calendar.getTime();
		int day=calendar.get(Calendar.DAY_OF_MONTH);
		int end=0;
		Date endDay=calendar.getTime();
		if(year<calendar.get(Calendar.YEAR)||(year==calendar.get(Calendar.YEAR)&&(month-1)<calendar.get(Calendar.MONDAY))) {
			//获取本月最后一天
			calendar.set(Calendar.YEAR, year);
			calendar.set(Calendar.MONTH, month);
			calendar.set(Calendar.DAY_OF_MONTH, 1);
			calendar.set(Calendar.HOUR_OF_DAY, 0);
			calendar.set(Calendar.MINUTE, 0);
			calendar.set(Calendar.SECOND, -1);
			endDay=calendar.getTime();
			end=calendar.get(Calendar.DAY_OF_MONTH);
		}else if(year==calendar.get(Calendar.YEAR)&&(month-1)==calendar.get(Calendar.MONDAY)){
			endDay=current;
			end=day;
		}
		for(int i=1;i<=end;i++) {
			calendar.set(Calendar.YEAR, year);
			calendar.set(Calendar.MONTH, month-1);
			calendar.set(Calendar.DAY_OF_MONTH, i);
			calendar.set(Calendar.HOUR_OF_DAY, 0);
			calendar.set(Calendar.MINUTE, 0);
			calendar.set(Calendar.SECOND, 0);
			list.add(calendar.getTime());
		}
		list.add(endDay);
		return list;
	}
	/**
	 * 获取当天的时间列表信息
	 * @param year
	 * @param month
	 * @param day
	 * @return
	 */
	private static List<Date>getListHour(int year,int month,int day){
		List<Date>list=new ArrayList<Date>();
		Calendar calendar=Calendar.getInstance();
		Date current=calendar.getTime();
		//是当天时间
		int end=0;
		boolean isCurrent=false;
		if(year==calendar.get(Calendar.YEAR)&&(month-1)==calendar.get(Calendar.MONTH)&&day==calendar.get(Calendar.DAY_OF_MONTH)) {
			//获取现在时间
			end=calendar.get(Calendar.HOUR_OF_DAY);
			isCurrent=true;
		}else {
			end=23;
		}
		for(int i=0;i<=end;i++) {
			calendar.set(Calendar.YEAR, year);
			calendar.set(Calendar.MONTH, month-1);
			calendar.set(Calendar.DAY_OF_MONTH, day);
			calendar.set(Calendar.HOUR_OF_DAY, i);
			calendar.set(Calendar.MINUTE, 0);
			calendar.set(Calendar.SECOND, 0);
			list.add(calendar.getTime());
		}
		if(isCurrent) {
			list.add(current);
		}else {
			calendar.set(Calendar.YEAR, year);
			calendar.set(Calendar.MONTH, month-1);
			calendar.set(Calendar.DAY_OF_MONTH, day+1);
			calendar.set(Calendar.HOUR_OF_DAY, 0);
			calendar.set(Calendar.MINUTE, 0);
			calendar.set(Calendar.SECOND, -1);
			list.add(calendar.getTime());
		}
		return list;
	}
	/**
	 * 获取当天小时列表
	 * @param year
	 * @param month
	 * @param day
	 * @param hour
	 * @return
	 */
	private static List<Date>getListMinut(int year,int month,int day,int hour){
		List<Date>list=new ArrayList<Date>();
		Calendar calendar=Calendar.getInstance();
		Date current=calendar.getTime();
		int minut=0;
		if(year==calendar.get(Calendar.YEAR)&&(month-1)==calendar.get(Calendar.MONTH)&&day==calendar.get(Calendar.DAY_OF_MONTH)&&hour==calendar.get(Calendar.HOUR_OF_DAY)) {
			minut=calendar.get(Calendar.MINUTE);
		}else {
			minut=60;
		}
		//每5分钟统计一次
		for(int i=0;i<=minut;i+=5) {
			calendar.set(Calendar.YEAR, year);
			calendar.set(Calendar.MONTH, month-1);
			calendar.set(Calendar.DAY_OF_MONTH, day);
			calendar.set(Calendar.HOUR_OF_DAY,hour);
			calendar.set(Calendar.MINUTE, i);
			calendar.set(Calendar.SECOND, 0);
			list.add(calendar.getTime());
		}
		return list;
	}

}
