package com.trilink.counter.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.trilink.counter.entity.InterfaceMethod;
import com.trilink.counter.mapper.InterfaceMethodMapper;

@Service
public class InterfaceMethodService {
	@Autowired
	private InterfaceMethodMapper interfaceMethodMapper;
	/**
	 * 查询接口信息
	 * @return
	 */
	public Map<String,Object> listInterfaceMethod(Integer page,Integer rows){
		Map<String,Object>result=new HashMap<String,Object>();
		PageHelper.startPage(page, rows);
		List<InterfaceMethod> list=interfaceMethodMapper.selectByExample(null);
		PageInfo<InterfaceMethod> pageinfo=new PageInfo<>(list);
		result.put("data", pageinfo.getList());
		result.put("total", pageinfo.getTotal());
		result.put("errCode", 0);
		result.put("errMsg", "查询成功");
		return result;
	}
}
