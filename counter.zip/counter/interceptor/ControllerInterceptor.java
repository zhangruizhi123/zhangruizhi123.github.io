//package com.trilink.counter.interceptor;
//
//import java.util.ArrayList;
//import java.util.Date;
//import java.util.HashMap;
//import java.util.LinkedList;
//import java.util.List;
//import java.util.Map;
//
//import javax.servlet.http.HttpServletRequest;
//
//import org.aspectj.lang.ProceedingJoinPoint;
//import org.aspectj.lang.annotation.Around;
//import org.aspectj.lang.annotation.Aspect;
//import org.aspectj.lang.annotation.Pointcut;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Component;
//import org.springframework.web.context.request.RequestContextHolder;
//import org.springframework.web.context.request.ServletRequestAttributes;
//
//import com.google.gson.Gson;
//import com.trilink.counter.entity.InterfaceCounter;
//import com.trilink.counter.mapper.InterfaceCounterMapper;
//
///***
// * aop拦截器获取返回值(返回对象里面有 errCode字段的可以做出处理)
// * 
// * @author acer
// *
// */
//@Aspect
//@Component
//public class ControllerInterceptor {
//	@Autowired
//	private InterfaceCounterMapper interfaceCounterMapper;
//	//用于存放请求数据
//	private static List<InterfaceCounter> list=new ArrayList<InterfaceCounter>();
//	
//	public static final int UPDATESIZE=100;
//	/**
//	 * 定义拦截规则：拦截com.xjj.web.controller包下面的所有类中，有@RequestMapping注解的方法。
//	 */
//	@Pointcut("(execution(* com.trilink.common.controller..*(..)) || execution(* com.trilink.counter.controller..*(..))) and @annotation(org.springframework.web.bind.annotation.RequestMapping)")
//	//@Pointcut("execution(* com.trilink.common.controller..*(..))  and @annotation(org.springframework.web.bind.annotation.RequestMapping)")
//	public void controllerMethodPointcut() {
//		
//	}
//
//	/**
//	 * 拦截器具体实现
//	 * 
//	 * @param pjp
//	 * @return JsonResult（被拦截方法的执行结果，或需要登录的错误提示。）
//	 */
//	@Around("controllerMethodPointcut()") // 指定拦截器规则；也可以直接把“execution(* com.xjj.........)”写进这里
//	public Object Interceptor(ProceedingJoinPoint pjp) {
//		Object result = null;
//		Gson gson = new Gson();
//		ServletRequestAttributes requestAttributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
//		HttpServletRequest httpServletRequest = requestAttributes.getRequest();
//		//获取请求路径
//		String url=httpServletRequest.getRequestURI();
//		String appId=httpServletRequest.getParameter("appId");
//		Map<String, String[]>  par=httpServletRequest.getParameterMap();
//		//获取请求参数
//		String param="无法获取参数信息";
//		String errMsg;
//		int mcode=-1;
//		
//		try {
//			result = pjp.proceed();
//			if(par!=null) {
//				param=gson.toJson(par);
//				//删除表情字符串
//				param=removeFourChar(param);
//			}
//			
//			String json = gson.toJson(result);
//			Map<String, Object> reponse = gson.fromJson(json, Map.class);
//			Object code = reponse.get("errCode");
//			if(code==null) {
//				code = reponse.get("errorCode");
//			}
//			if(reponse.get("errMsg")==null) {
//				errMsg = (String)reponse.get("msg");
//			}else {
//				errMsg = (String)reponse.get("errMsg");
//				
//			}
//			if (code != null) {
//				if (code instanceof Integer) {
//					mcode=(int)(code);
//				} else if (code instanceof String) {
//					mcode=Integer.parseInt((String)code);
//				} else if (code instanceof Double) {
//					Double cd=(Double)code;
//					mcode=cd.intValue();
//				} else if (code instanceof Long) {
//					mcode=(int)(code);
//				}
//
//			}
//		} catch (Throwable e) {
//			mcode=-2;
//			errMsg= "无法获取更多信息\t"+e.getMessage();
//			e.printStackTrace();
//		}
//		//对数据进行处理
//		try {
//			//对数据字段进行截取
//			if(param!=null&&param.length()>2999) {
//				param=param.substring(0, 2999);
//			}
//			if(errMsg!=null&&errMsg.length()>299) {
//				System.out.println("过长的返回信息:"+errMsg);
//				errMsg=errMsg.substring(0, 299);
//			}
//			if(url!=null&&url.length()>299) {
//				url=url.substring(0, 299);
//			}
//			InterfaceCounter InterfaceCounter=new InterfaceCounter();
//			InterfaceCounter.setPath(url);
//			//InterfaceCounter.setParam();
//			InterfaceCounter.setMessage(errMsg);
//			InterfaceCounter.setStatus(mcode);
//			InterfaceCounter.setCreateTime(new Date());
//			InterfaceCounter.setAppId(appId);
//			list.add(InterfaceCounter);
//			if(list.size()>=UPDATESIZE) {
//				interfaceCounterMapper.insertList(list);
//				list=new ArrayList<InterfaceCounter>();
//			}
//		}catch(Exception e) {
//			System.out.println("\r\n\r\n数据库插入数据失败\r\n\r\n");
//			e.printStackTrace();
//		}finally{
//			//最后清空list
//			if(list.size()>=UPDATESIZE) {
//				list=new ArrayList<InterfaceCounter>();
//			}
//		}
//		return result;
//	}
//	
//	//过滤表情字符
//	public static String removeFourChar(String content) {
//        byte[] conbyte = content.getBytes();
//        for (int i = 0; i < conbyte.length; i++) {
//            if ((conbyte[i] & 0xF8) == 0xF0) {
//                for (int j = 0; j < 4; j++) {                          
//                    conbyte[i+j]=0x30;                     
//                }  
//                i += 3;
//            }
//        }
//        content = new String(conbyte);
//        return content.replaceAll("0000", "");
//    }
//
//}