package com.trilink.counter.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.trilink.counter.service.InterfaceMethodService;
import com.trilink.counter.annotation.InterfaceDescript;
/**
 * 统计系统接口的数量和基本信息
 * @author acer
 *
 */
@Controller
@RequestMapping("interfaceMethod")
public class InterfaceMethodController {
	
	@Autowired
	private InterfaceMethodService interfaceMethodService;
	
	@RequestMapping("/listMethod")
	@ResponseBody
	@InterfaceDescript("获取系统中的调用接口信息")
	public Map<String,Object> listMethod(Integer page,Integer rows) {
		if(page==null||page<=0) {
			page=1;
		}
		if(rows==null||rows<=0) {
			rows=10;
		}
		Map<String,Object>result=new HashMap<String,Object>();
		try {
			result=interfaceMethodService.listInterfaceMethod(page, rows);
		}catch(Exception e) {
			result.put("errCode", 101);
			result.put("errMsg", "查询失败");
		}
		return result;
	}
}
