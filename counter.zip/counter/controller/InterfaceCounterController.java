package com.trilink.counter.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.trilink.counter.annotation.InterfaceDescript;
import com.trilink.counter.service.InterfaceCounterService;

/**
 * 统计接口请求量
 * @author acer
 *
 */
@Controller
@RequestMapping("interfaceCounter")
public class InterfaceCounterController {
	
	@Autowired
	private InterfaceCounterService interfaceCounterService;
	
	
	@RequestMapping("counterInterface")
	@ResponseBody
	@InterfaceDescript("统计接口请求量")
	/**
	 * 统计信息
	 * @param type 类型，1:年,2:月,3:日,4:小时,5:分
	 * @param year
	 * @param month
	 * @param day
	 * @param hour
	 * @param min
	 * @return
	 */
	public Map<String,Object>counterInterface(Integer type,Integer year,Integer month,Integer day,Integer hour){
		Map<String,Object>result=new HashMap<String,Object>();
		if(type==null) {
			type=1;
			year=2010;
		}
		if(type==1) {
			year=2010;
		}
		try {
			result=interfaceCounterService.counterInterface(type,year,month,day,hour);
		}catch(Exception e) {
			result.put("errCode", 101);
			result.put("errMsg", "查询失败:"+e.getMessage());
		}
		return result;
	}
	
	@RequestMapping("counterMathods")
	@ResponseBody
	@InterfaceDescript("某个接口的单位请求量")
	/**
	 * 
	 * @param type 类型，1:年,2:月,3:日,4:小时,5:分
	 * @param year
	 * @param month
	 * @param day
	 * @param hour
	 * @return
	 */
	public Map<String,Object>counterMathods(Integer type,Integer year,Integer month,Integer day,Integer hour){
		Map<String,Object>result=new HashMap<String,Object>();
		if(type==null) {
			type=1;
			year=2010;
		}
		try {
			result=interfaceCounterService.counterMathods(type,year,month,day,hour);
		}catch(Exception e) {
			result.put("errCode", 101);
			result.put("errMsg", "查询失败:"+e.getMessage());
		}
		return result;
	}
	
	@RequestMapping("mathodsDetail")
	@ResponseBody
	@InterfaceDescript("所有接口的详细信息")
	/**
	 * 
	 * @param order 1位降序，2为升序（时间）
	 * @param page默认值为1
	 * @param rows
	 * @return
	 */
	public Map<String,Object>mathodsDetail(Integer order,Integer page,Integer rows,String start,String end){
		Map<String,Object>result=new HashMap<String,Object>();
		if(page==null||page<1) {
			page=1;
		}
		if(order==null||order<1) {
			order=1;
		}
		if(rows==null||rows<1) {
			rows=10;
		}
		try {
			result=interfaceCounterService.mathodsDetail(order,page,rows,start,end);
		}catch(Exception e) {
			result.put("errCode", 101);
			result.put("errMsg", "查询失败:"+e.getMessage());
		}
		return result;
	}
	
}
