package com.trilink.counter.mapper;

import java.util.Date;
import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.trilink.counter.entity.InterfaceCounter;
import com.trilink.counter.entity.InterfaceCounterExample;



public interface InterfaceCounterMapper {
    int countByExample(InterfaceCounterExample example);

    int deleteByExample(InterfaceCounterExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(InterfaceCounter record);

    int insertSelective(InterfaceCounter record);

    List<InterfaceCounter> selectByExample(InterfaceCounterExample example);

    InterfaceCounter selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") InterfaceCounter record, @Param("example") InterfaceCounterExample example);

    int updateByExample(@Param("record") InterfaceCounter record, @Param("example") InterfaceCounterExample example);

    int updateByPrimaryKeySelective(InterfaceCounter record);

    int updateByPrimaryKey(InterfaceCounter record);
    
    List<InterfaceCounter> countByDate(@Param("start")Date start,@Param("end")Date end);
    
    int insertList(@Param("recordList")List<InterfaceCounter> recordList);
}