package com.trilink.counter.mapper;

import com.trilink.counter.entity.InterfaceMethod;
import com.trilink.counter.entity.InterfaceMethodExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface InterfaceMethodMapper {
    int countByExample(InterfaceMethodExample example);

    int deleteByExample(InterfaceMethodExample example);

    int deleteByPrimaryKey(String path);

    int insert(InterfaceMethod record);

    int insertSelective(InterfaceMethod record);

    List<InterfaceMethod> selectByExample(InterfaceMethodExample example);

    InterfaceMethod selectByPrimaryKey(String path);

    int updateByExampleSelective(@Param("record") InterfaceMethod record, @Param("example") InterfaceMethodExample example);

    int updateByExample(@Param("record") InterfaceMethod record, @Param("example") InterfaceMethodExample example);

    int updateByPrimaryKeySelective(InterfaceMethod record);

    int updateByPrimaryKey(InterfaceMethod record);
    
    int insertList(@Param("recordList") List<InterfaceMethod> recordList);
}