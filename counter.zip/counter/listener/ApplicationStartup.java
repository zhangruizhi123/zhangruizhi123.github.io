package com.trilink.counter.listener;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.annotation.WebListener;

import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.handler.AbstractHandlerMethodMapping;
import org.springframework.web.servlet.mvc.method.RequestMappingInfo;

import com.trilink.counter.entity.InterfaceMethod;
import com.trilink.counter.mapper.InterfaceMethodMapper;
import com.trilink.counter.annotation.InterfaceDescript;
/**
 * 该方法是项目启动后执行的方法
 * @author acer
 *
 */
@WebListener
public class ApplicationStartup implements ApplicationListener<ContextRefreshedEvent>{

	@Override
	public void onApplicationEvent(ContextRefreshedEvent event) {
		//getAllUrls(event);
	}
	
	/**
	 * 获取所有的url数据
	 * @param event
	 */
	public void getAllUrls(ContextRefreshedEvent event) {

		AbstractHandlerMethodMapping<RequestMappingInfo> objHandlerMethodMapping =(AbstractHandlerMethodMapping<RequestMappingInfo>) event.getApplicationContext().getBean("requestMappingHandlerMapping");
		InterfaceMethodMapper interfaceMethodMapper=event.getApplicationContext().getBean(InterfaceMethodMapper.class);
		Map<RequestMappingInfo, HandlerMethod> mapRet = objHandlerMethodMapping.getHandlerMethods();
		//先删除所有数据
		interfaceMethodMapper.deleteByExample(null);
		if(mapRet!=null){
			List<InterfaceMethod>InterfaceMethodList=new ArrayList<InterfaceMethod>();
			Date date=new Date();
			for(RequestMappingInfo info:mapRet.keySet()) {
				HandlerMethod handlerMethod=mapRet.get(info);
				//获取对应的类
				String type=handlerMethod.getBeanType().getName();
				//获取方法
				Method method=handlerMethod.getMethod();
				InterfaceDescript interfaceScript=method.getAnnotation(InterfaceDescript.class);
				String name=method.getName();
				//只对有该注解的方法做处理
				if(interfaceScript!=null) {
					String descript=interfaceScript.value();
					//获取url
					Set<String> urls=info.getPatternsCondition().getPatterns();
					for(String url:urls) {
						InterfaceMethod interfaceMethod=new InterfaceMethod();
						interfaceMethod.setPath(url);
						interfaceMethod.setClassName(type);
						interfaceMethod.setMethodName(name);
						interfaceMethod.setRmark(descript);
						interfaceMethod.setCreateTime(date);
						InterfaceMethodList.add(interfaceMethod);
					}
				}
			}
			
			if(InterfaceMethodList.size()>0) {
				//将获取的url信息插入到数据库中
				interfaceMethodMapper.insertList(InterfaceMethodList);
			}
		}
	}

}
